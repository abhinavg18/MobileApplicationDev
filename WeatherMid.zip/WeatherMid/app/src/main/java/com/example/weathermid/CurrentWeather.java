package com.example.weathermid;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import org.apache.commons.io.IOUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

import static java.security.AccessController.getContext;

public class CurrentWeather extends AppCompatActivity {

    TextView temp, tempmax,tempmin, humidity, description, windspeed,title;
    ImageView imageView;
    Button forecast;
    String urllast;
    String urlbase="http://api.openweathermap.org/data/2.5/";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_current_weather);

        temp= findViewById(R.id.tv_tempval);
        tempmax=findViewById(R.id.tv_tempmaxval);
        tempmin=findViewById(R.id.tv_tempminval);
        description=findViewById(R.id.tv_decripval);
        humidity=findViewById(R.id.tv_humidityval);
        windspeed=findViewById(R.id.tv_windval);
        title=findViewById(R.id.tv_cityval);

        if(getIntent()!=null) {
            if(getIntent().getExtras()!=null) {
                 urllast=getIntent().getExtras().getString("url");
                String urlCall=urlbase+"weather?"+urllast;
                String citytitle=getIntent().getExtras().getString("city");
                title.setText(citytitle);

                new GetDataAsync().execute(urlCall);
            }
        }
        }
    private class GetDataAsync extends AsyncTask<String, Void, Weather> {
        ProgressDialog pb;
       /* RecyclerView mRecyclerView;
        RecyclerView.Adapter mAdapter;
        RecyclerView.LayoutManager mLayoutManager;*/


        @Override
        protected void onPreExecute() {
           /* pb = new ProgressDialog(CurrentWeather.this);
            pb.setMessage("Loading");
            pb.setMax(100);
            pb.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            pb.setCancelable(false);
            pb.show();*/
        }

        @Override
        protected void onProgressUpdate(Void... values) {
          //  pb.setProgress(values[0]);
        }

        @Override
        protected void onPostExecute(Weather result) {
         //   pb.dismiss();
            if(result==null){
                Toast.makeText(CurrentWeather.this, "No details Found", Toast.LENGTH_SHORT).show();
            }
            else {
                temp= findViewById(R.id.tv_tempval);
                tempmax=findViewById(R.id.tv_tempmaxval);
                tempmin=findViewById(R.id.tv_tempminval);
                description=findViewById(R.id.tv_decripval);
                humidity=findViewById(R.id.tv_humidityval);
                windspeed=findViewById(R.id.tv_windval);
                imageView=findViewById(R.id.iv_type);
                String urlimage="http://openweathermap.org/img/wn/"+result.icon+"@2x.png";
                try {
                    Picasso.get().load(urlimage).into(imageView);
                }catch (Exception e){
                    imageView.setImageDrawable(null);

                    e.printStackTrace();
                }



                temp.setText(result.temp.toString()+" F");
                tempmax.setText(result.tempmax.toString()+" F");
                tempmin.setText(result.tempmin.toString()+" F");
                description.setText(result.description);
                humidity.setText(result.humidity.toString()+"%");
                windspeed.setText(result.windspeed.toString()+" miles/hr");

                Button button= findViewById(R.id.button);
                button.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        String urltosend= urlbase+"forecast?"+urllast;
                        Intent i= new Intent(CurrentWeather.this, Forecast.class);
                        i.putExtra("secondcall",urltosend);
                        startActivity(i);

                        finish();
                    }
                });


/* api.openweathermap.org/data/2.5/forecast?
                            q=London,us&appid=<API_Key>
*/


            }
        }


        @Override
        protected Weather doInBackground(String... params) {
            HttpURLConnection connection = null;
            Weather weather= new Weather();

            try {
                URL url = new URL(params[0]);
                connection = (HttpURLConnection) url.openConnection();
                connection.connect();
                if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {


                    String json = IOUtils.toString(connection.getInputStream(), "UTF8");


                    JSONObject root = new JSONObject(json);
                    JSONArray weatherval = root.getJSONArray("weather");
                    JSONObject weatherJSON = weatherval.getJSONObject(0);
                    weather.description=weatherJSON.getString("description");
                    weather.icon=weatherJSON.getString("icon");
                 //   JSONArray mainval = root.getJSONArray("main");
                    JSONObject mainJSON = root.getJSONObject("main");
                    weather.temp=mainJSON.getDouble("temp");
                    weather.tempmin=mainJSON.getDouble("temp_min");
                    weather.tempmax=mainJSON.getDouble("temp_max");
                    weather.humidity=mainJSON.getDouble("humidity");
                 //   JSONArray wind = root.getJSONArray("wind");
                    JSONObject windJSON = root.getJSONObject("wind");
                    weather.windspeed=windJSON.getDouble("speed");






                }
            }catch (IOException ex) {
                ex.printStackTrace();
            } catch (JSONException ex) {
                ex.printStackTrace();
            } finally {
                if (connection != null) {
                    connection.disconnect();
                }
            }
            return weather;
        }
    }


}

