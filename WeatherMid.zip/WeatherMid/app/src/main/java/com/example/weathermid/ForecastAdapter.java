package com.example.weathermid;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class ForecastAdapter extends RecyclerView.Adapter<ForecastAdapter.MyViewHolder> {
    ArrayList<ForecastperItem> mData;


    public  ForecastAdapter(ArrayList<ForecastperItem> mData){
        this.mData=mData;
    }
    public static class MyViewHolder extends RecyclerView.ViewHolder{

        //declare the variable for the xml doc and one for the obj type
        TextView fore_temp,fore_time,fore_desc,fore_humid;
        ImageView iv_fore;
        ForecastperItem s;
        public MyViewHolder(@NonNull final View itemView) {
            super(itemView);
            // get the id's of xml layout in this
            fore_temp= itemView.findViewById(R.id.fore_temp );
            fore_time= itemView.findViewById(R.id.fore_time);
            fore_desc= itemView.findViewById(R.id.fore_desc );
            fore_humid= itemView.findViewById(R.id.fore_humid);
            iv_fore=itemView.findViewById(R.id.fore_iv);


        }
    }

    @NonNull
    @Override
    public ForecastAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.itemforecast, parent, false);

        MyViewHolder viewHolder= new MyViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ForecastAdapter.MyViewHolder holder, int position) {
        try {
            ForecastperItem fore = mData.get(position);
            holder.fore_temp.setText("Temperature "+fore.temp);
            holder.fore_desc.setText("Description "+fore.description);
            holder.fore_humid.setText("Humidity "+fore.humidity);
            holder.fore_time.setText("Time "+ fore.time);
            String urlimage="http://openweathermap.org/img/wn/"+fore.icon+"@2x.png";
            try {
                Picasso.get().load(urlimage).into(holder.iv_fore);
            }catch (Exception e){
                holder.iv_fore.setImageDrawable(null);

                e.printStackTrace();
            }
            /*SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
            SimpleDateFormat outputFormat = new SimpleDateFormat("MM-dd-yyyy kk:mm:ss");

            Date date = inputFormat.parse(song.updated_time);
            String formattedDate = outputFormat.format(date);

            Date convertedDate= new Date();
            convertedDate= inputFormat.parse(song.updated_time);
            PrettyTime p  = new PrettyTime();

            String datetime= p.format(convertedDate);
*/

  //          holder.updated_time.setText(datetime);
    //        holder.s = song;
        }catch(Exception ex){
            ex.printStackTrace();
        }
    }

    @Override
    public int getItemCount() {
        if (mData==null)
            return 0;
        else
            return mData.size();
    }
}
