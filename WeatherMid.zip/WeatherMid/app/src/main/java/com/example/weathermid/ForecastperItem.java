package com.example.weathermid;

public class ForecastperItem {

    String temp, humidity, description,icon,time;
}
