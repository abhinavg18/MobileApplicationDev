package com.example.weathermid;

public class Weather {
    Double temp, tempmax, tempmin, humidity, windspeed;
    String description,icon;

}
