package com.example.weathermid;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import org.apache.commons.io.IOUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class Forecast extends AppCompatActivity {

    RecyclerView mRecyclerView;
    RecyclerView.Adapter mAdapter;
    RecyclerView.LayoutManager mLayoutManager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forecast);


        String url=getIntent().getExtras().getString("secondcall");

        new GetDataAsync().execute(url);

         mRecyclerView= findViewById(R.id.recyclerViewTasks);
                        // final SongAdapter songAdapter= new SongAdapter(MainActivity.this, R.layout.search_detail,result);
                        mRecyclerView.setHasFixedSize(true);
                        // use a linear layout manager
                        mLayoutManager = new LinearLayoutManager(this);
                        mRecyclerView.setLayoutManager(mLayoutManager);
                        mAdapter= new ForecastAdapter(null);
                        mRecyclerView.setAdapter(mAdapter);


    }

    private class GetDataAsync extends AsyncTask<String, Void, ArrayList<ForecastperItem>> {
        ProgressDialog pb;
       /* RecyclerView mRecyclerView;
        RecyclerView.Adapter mAdapter;
        RecyclerView.LayoutManager mLayoutManager;*/


        @Override
        protected void onPreExecute() {
           /* pb = new ProgressDialog(CurrentWeather.this);
            pb.setMessage("Loading");
            pb.setMax(100);
            pb.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            pb.setCancelable(false);
            pb.show();*/
        }

        @Override
        protected void onProgressUpdate(Void... values) {
            //  pb.setProgress(values[0]);
        }

        @Override
        protected void onPostExecute(ArrayList<ForecastperItem> result) {
            //   pb.dismiss();
            if(result.size()==0){
                Toast.makeText(Forecast.this, "No details Found", Toast.LENGTH_SHORT).show();
            }
            else {

                 mAdapter= new ForecastAdapter(result);
                mRecyclerView.setAdapter(mAdapter);
            mAdapter.notifyDataSetChanged();
                /*temp= findViewById(R.id.tv_tempval);
                tempmax=findViewById(R.id.tv_tempmaxval);
                tempmin=findViewById(R.id.tv_tempminval);
                description=findViewById(R.id.tv_decripval);
                humidity=findViewById(R.id.tv_humidityval);
                windspeed=findViewById(R.id.tv_windval);
                imageView=findViewById(R.id.iv_type);
                String urlimage="http://openweathermap.org/img/wn/"+result.icon+"@2x.png";
                try {
                    Picasso.with(CurrentWeather.this).load(urlimage).into(imageView);
                }catch (Exception e){
                    imageView.setImageDrawable(null);

                    e.printStackTrace();
                }
*/


                /*temp.setText(result.temp.toString()+" F");
                tempmax.setText(result.tempmax.toString()+" F");
                tempmin.setText(result.tempmin.toString()+" F");
                description.setText(result.description);
                humidity.setText(result.humidity.toString()+"%");
                windspeed.setText(result.windspeed.toString()+" miles/hr");
*/


/* api.openweathermap.org/data/2.5/forecast?
                            q=London,us&appid=<API_Key>
*/


            }
        }


        @Override
        protected ArrayList<ForecastperItem> doInBackground(String... params) {
            HttpURLConnection connection = null;
            ArrayList<ForecastperItem> forecastList= new ArrayList<>();

            try {
                URL url = new URL(params[0]);
                connection = (HttpURLConnection) url.openConnection();
                connection.connect();
                if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {


                    String json = IOUtils.toString(connection.getInputStream(), "UTF8");


                    JSONObject root = new JSONObject(json);
                    JSONArray list = root.getJSONArray("list");
                    for(int i=0;i<list.length();i++){
                        ForecastperItem forecast= new ForecastperItem();
                        JSONObject listJSONObject = list.getJSONObject(i);
                        JSONObject main= listJSONObject.getJSONObject("main");
                        forecast.temp=main.getString("temp");
                        forecast.humidity=main.getString("humidity");
                        JSONArray weather= listJSONObject.getJSONArray("weather");
                        JSONObject weatherJSON = weather.getJSONObject(0);
                        forecast.description=weatherJSON.getString("description");
                        forecast.icon=weatherJSON.getString("icon");

                        forecastList.add(forecast);
                    }





                }
            }catch (IOException ex) {
                ex.printStackTrace();
            } catch (JSONException ex) {
                ex.printStackTrace();
            } finally {
                if (connection != null) {
                    connection.disconnect();
                }
            }
            return forecastList;
        }
    }


}
