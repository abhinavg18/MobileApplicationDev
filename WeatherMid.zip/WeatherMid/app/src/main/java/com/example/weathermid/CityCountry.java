package com.example.weathermid;

public class CityCountry {
    String city, country;
}
