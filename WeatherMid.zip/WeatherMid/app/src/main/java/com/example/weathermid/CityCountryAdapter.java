package com.example.weathermid;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;


import java.util.List;

public class CityCountryAdapter extends ArrayAdapter<CityCountry> {
    public CityCountryAdapter(@NonNull Context context, int resource, @NonNull List<CityCountry> objects) {
        super(context, resource, objects);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        CityCountry cityCountry= getItem(position);
        ViewHolder viewHolder;
        try{
            if(convertView==null){
                convertView= LayoutInflater.from(getContext()).inflate(R.layout.citynames,parent,false);
                viewHolder = new ViewHolder();
                viewHolder.tv_city= convertView.findViewById(R.id.tv_city);

                convertView.setTag(viewHolder);
            }else {
                viewHolder = (ViewHolder) convertView.getTag();
            }

            viewHolder.tv_city.setText(cityCountry.city + ","+ cityCountry.country);

    }catch(Exception ex){
            Toast.makeText(getContext(),"Something went wrong!",Toast.LENGTH_SHORT).show();
        }
        return convertView;
    }

    private static class ViewHolder{
        TextView tv_city;

    }
}
