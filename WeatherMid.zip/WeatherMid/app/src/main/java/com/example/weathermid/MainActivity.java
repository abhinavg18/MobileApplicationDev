package com.example.weathermid;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;

/*Abhinav Gupta
801134237*/

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ArrayList<CityCountry> cclist= new ArrayList<>();
        try {
        String json= loadJSONFromAsset(this);

            JSONObject root = new JSONObject(json);
           // JSONObject data = root.getJSONObject("data");
            JSONArray data = root.getJSONArray("data");
            for(int i=0; i<data.length();i++){
                JSONObject dataJSON= data.getJSONObject(i);
                CityCountry cc= new CityCountry();
                cc.city= dataJSON.getString("city");
                cc.country= dataJSON.getString("country");
                cclist.add(cc);
            }
            ListView listView= findViewById(R.id.listview);
            final CityCountryAdapter cityCountryAdapter= new CityCountryAdapter(MainActivity.this, R.layout.citynames,cclist);
            listView.setAdapter(cityCountryAdapter);

            listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                    CityCountry ccval= cityCountryAdapter.getItem(i);

                    String url = "q="+ccval.city+","+ccval.country+"&appid=bc7e403ff95d4a6ab53f3416ace575f5";
                    Intent intent = new Intent(MainActivity.this,CurrentWeather.class);
                    intent.putExtra("url",url);
                    intent.putExtra("city",ccval.city+","+ccval.country);

                    startActivity(intent);

                }
            });




        } catch (JSONException e) {
            e.printStackTrace();
        }


    }

    public String loadJSONFromAsset(Context context) {
        String json = null;
        try {
            InputStream is = getResources().openRawResource(R.raw.cities);



            int size = is.available();

            byte[] buffer = new byte[size];

            is.read(buffer);

            is.close();

            json = new String(buffer, "UTF-8");


        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (IOException ex) {
            ex.printStackTrace();
            return null;
        }
        return json;

    }
}
